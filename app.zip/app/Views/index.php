<?php 
include('templates/header.php');
include('templates/nav.php');
include('templates/produtos.php');
include('templates/sobre.php');
include('templates/contato.php');
include('templates/footer.php');
include('templates/end.php');

?>

        

        

        

        

            

            

            